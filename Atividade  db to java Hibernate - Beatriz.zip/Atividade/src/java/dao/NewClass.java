/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import modelBean.Cliente;
import modelBean.Compra;
import modelBean.Produto;
import modelBean.Vendedor;

/**
 *
 * @author alunosenai
 */
public class NewClass {
    
    public static void main(String[] args) {
        
       Cliente cliente = new Cliente();
       ClienteDao cld = new ClienteDao();
       cliente.setNomeCliente("Alex");
       cld.salvar(cliente);
       
       Produto produto = new Produto();
       ProdutoDao prodd = new ProdutoDao();
       produto.setNomeProd("CD");
       prodd.salvar(produto);
       
       Vendedor vendedor = new Vendedor();
       VendedorDao vendd = new VendedorDao();
       vendedor.setNome("Jorge");
       vendd.salvar(vendedor);
        
       Compra compra = new Compra();
       CompraDao compd = new CompraDao();
       compra.setId(1);
       compra.setCliente(cliente);
       compra.setVendedor(vendedor);
       compra.setProduto(produto);
       compd.salvar(cliente, produto, vendedor);
    }
    
}
