/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import config.HibernateUtil;
import modelBean.Vendedor;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author alunosenai
 */
public class VendedorDao {
   private Session s = null;
private Transaction t = null;

public void salvar(Vendedor vendedor){
    
    s = HibernateUtil.getSessionFactory().openSession();
    t = s.beginTransaction();
    s.save(vendedor);
    t.commit(); //salvar no banco
    System.out.println("Salvo");
    } 
}
