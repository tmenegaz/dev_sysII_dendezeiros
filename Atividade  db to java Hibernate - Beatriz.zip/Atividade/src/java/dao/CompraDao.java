/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import config.HibernateUtil;
import modelBean.Cliente;
import modelBean.Compra;
import modelBean.Produto;
import modelBean.Vendedor;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author alunosenai
 */
public class CompraDao {
    private Session s = null;
    private Transaction t = null;

public void salvar(Cliente cliente, Produto produto, Vendedor vendedor){
    Compra compra = new Compra();
    s = HibernateUtil.getSessionFactory().openSession();
    t = s.beginTransaction();
    s.save(compra);
    t.commit(); //salvar no banco
    System.out.println("Salvo");
    } 
    
}
