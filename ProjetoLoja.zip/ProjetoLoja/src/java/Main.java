
import Modelo.DAO.DAO;
import Modelo.Gerente;
import Modelo.GerenteProjetoLocalidade;
import Modelo.GerenteProjetoLocalidadePK;
import Modelo.Localidade;
import Modelo.Projeto;
import java.util.Scanner;

public class Main{
public static void main(String[] args) {
		
                
    DAO dao = new DAO();

                
                Scanner sc = new Scanner(System.in);
                int valor;
                String teste2;
                String teste;
                Gerente gerente = new Gerente();
                Projeto projeto = new Projeto();
                Localidade localidade = new Localidade();
                
                System.out.println("Escolha uma das opções:\n"
                        + " 1 para inserir\n"
                        + " 2 para Pesquisar\n"
                        + " 3 para Projeto\n"
                        + " 4 para Localidade");
                valor = sc.nextInt();
                    switch(valor){
            case 1:
                
                gerente.setNomeGerente("Felipe");
		dao.salvar(gerente);
                
               
                projeto.setNomeProjeto("Beta");
                dao.salvar(projeto);
                
               
                localidade.setNomeLocalidade("Salvador");
                dao.salvar(localidade);
                
                GerenteProjetoLocalidadePK gpl = new GerenteProjetoLocalidadePK();
                gpl.setIdGerente(gerente.getIdGerente());
                gpl.setIdProjeto(projeto.getIdProjeto());
                gpl.setIdLocalidade(localidade.getIdLocalidade());
                dao.salvar(gpl);
                break;
            case 2: 
            {
                System.out.println("Digite o nome do gerente:");
               teste = sc.nextLine(); 
               teste = sc.nextLine(); 
               dao.localizar(teste, gerente);
            }
                break;
                          
            case 3: 
                   {
                System.out.println("Digite o nome do projeto:");
               teste = sc.nextLine(); 
               teste = sc.nextLine(); 
               dao.localizar(teste, projeto);
               
            }
                break;
             
              case 4: 
                   {
                System.out.println("Digite o nome da localidade:");
               teste = sc.nextLine(); 
               teste = sc.nextLine(); 
               dao.localizar(teste, localidade);
               
            }
                break;    
                           
            default:
                System.out.println("Digite SOMENTE opção entre 1 a 4");
                break;
        }
                
                
                
                
                
                
                
                
		// Criando um segundo contato
		                                
         	}
}