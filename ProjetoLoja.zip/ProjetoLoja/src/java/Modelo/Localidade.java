/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author alunosenai
 */
@Entity
@Table(name = "localidade")
@NamedQueries({
    @NamedQuery(name = "Localidade.findAll", query = "SELECT l FROM Localidade l")})
public class Localidade implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_localidade")
    private Integer idLocalidade;
    @Size(max = 20)
    @Column(name = "nome_localidade")
    private String nomeLocalidade;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idLocalidade")
    private List<GerenteProjetoLocalidade> gerenteProjetoLocalidadeList;

    public Localidade() {
    }

    public Localidade(Integer idLocalidade) {
        this.idLocalidade = idLocalidade;
    }

    public Integer getIdLocalidade() {
        return idLocalidade;
    }

    public void setIdLocalidade(Integer idLocalidade) {
        this.idLocalidade = idLocalidade;
    }

    public String getNomeLocalidade() {
        return nomeLocalidade;
    }

    public void setNomeLocalidade(String nomeLocalidade) {
        this.nomeLocalidade = nomeLocalidade;
    }

    public List<GerenteProjetoLocalidade> getGerenteProjetoLocalidadeList() {
        return gerenteProjetoLocalidadeList;
    }

    public void setGerenteProjetoLocalidadeList(List<GerenteProjetoLocalidade> gerenteProjetoLocalidadeList) {
        this.gerenteProjetoLocalidadeList = gerenteProjetoLocalidadeList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLocalidade != null ? idLocalidade.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Localidade)) {
            return false;
        }
        Localidade other = (Localidade) object;
        if ((this.idLocalidade == null && other.idLocalidade != null) || (this.idLocalidade != null && !this.idLocalidade.equals(other.idLocalidade))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Localidade[ idLocalidade=" + idLocalidade + " ]";
    }
    
}
