package Modelo.DAO;


import Modelo.Gerente;
import Modelo.GerenteProjetoLocalidade;
import Modelo.GerenteProjetoLocalidadePK;
import Modelo.Localidade;
import Modelo.Projeto;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAO {

 
    Connection conexao = this.geraConexao();
	ResultSet rs;
    
        
    public void salvar(Gerente gerente) {
		PreparedStatement insereSt = null;
		String sql = "insert into gerente (nome_gerente) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1,gerente.getNomeGerente());
			insereSt.executeUpdate();
                        pesquisar(gerente);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Gerente: "
					+ e.getMessage());
		} 
    
    }
		
    
       public void salvar(Projeto projeto) {
		PreparedStatement insereSt = null;
		String sql = "insert into projeto (nome_projeto) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1,projeto.getNomeProjeto());
                                insereSt.executeUpdate();
                                pesquisar(projeto);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Projeto: "
					+ e.getMessage());
		} 
	}
    
    public void salvar(Localidade localidade) {
		PreparedStatement insereSt = null;
		String sql = "insert into localidade (nome_localidade) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1, localidade.getNomeLocalidade());
                                insereSt.executeUpdate();
                                pesquisar(localidade);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Localidade: "
					+ e.getMessage());
		} 
    }
    
    
   public void pesquisar(Gerente gerente){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from gerente where nome_gerente =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,gerente.getNomeGerente());
            ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                gerente.setIdGerente(rs.getInt("id_gerente"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
   }
      public void pesquisar(Projeto projeto){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from projeto where nome_projeto =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,projeto.getNomeProjeto());
            ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                projeto.setIdProjeto(rs.getInt("id_projeto"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
                
         public void pesquisar(Localidade localidade){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from localidade where nome_localidade =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,localidade.getNomeLocalidade());
                    ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                localidade.setIdLocalidade(rs.getInt("id_localidade"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }
         
         
          public void salvar(GerenteProjetoLocalidadePK gpl) {
                PreparedStatement insereSt = null;
		String sql = "insert into gerente_projeto_localidade (id_gerente,id_projeto,id_localidade) values (?,?,?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setInt(1,gpl.getIdGerente());
                        insereSt.setInt(2,gpl.getIdProjeto());
                        insereSt.setInt(3,gpl.getIdLocalidade());
                        insereSt.executeUpdate();
                        
                               
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Localidade: "
					+ e.getMessage());
		} 
    }

          private Connection geraConexao() {
		Connection conexao = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/loja";
			String usuario = "root";
			String senha = "";
			conexao = DriverManager.getConnection(url, usuario, senha);
		} catch (ClassNotFoundException e) {
			System.out
					.println("Classe não encontrada. Erro: " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Ocorreu um erro de SQL. Erro: "
					+ e.getMessage());
		}
		return conexao;
	}
          
         public void localizar(String teste, Gerente gerente){
       
       Statement ct = null;
      String sql = "select * from gerente where nome_gerente = '" + teste + "'";
       //String sql = "Select * from gerente";
        try {
            ct = conexao.createStatement();
            rs = ct.executeQuery(sql); 
             while (rs.next())
      {
    int id = rs.getInt("id_gerente");
        String nomeGerente= rs.getString("nome_gerente");
       // System.out.format("%s,%s",id, nomeGerente);
          System.out.println(rs.getInt("id_gerente")+","+rs.getString("nome_gerente"));
         // System.out.println(rs.getString("nome_gerente"));
             }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }  
         
        public void localizar(String teste, Projeto projeto){
       
       Statement ct = null;
       String sql2 = "SELECT DISTINCT `nome_gerente`, `nome_localidade` FROM `gerente`, `gerente_projeto_localidade`, `localidade` "
               + "WHERE `localidade`.`id_localidade`"
               + " IN (SELECT `localidade`.`id_localidade` FROM `localidade` "
               + "WHERE `nome_localidade` =  '" + teste + "'";
     // String sql = "select distinct * from gerente_projeto_localidade where id_localidade = '" + teste + "'";
 
               try {
            ct = conexao.createStatement();
            rs = ct.executeQuery(sql2); 
             while (rs.next())
      {
    int id = rs.getInt("id_projeto");
        String nomeProjeto= rs.getString("nome_projeto");
        
    System.out.println(rs.getInt("id_gerente")+","+rs.getString("nome_gerente")+"    -   "+rs.getInt("id_projeto")+","+rs.getString("nome_projeto"));
           
             }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }    
         
         

        public void localizar(String teste, Localidade localidade){
       
       Statement ct = null;
       String sql = "SELECT DISTINCT nome_gerente, nome_projeto, nome_localidade FROM gerente, gerente_projeto_localidade, localidade, projeto "
               + "WHERE localidade.id_localidade"
               + " IN (SELECT localidade.id_localidade FROM localidade "
               + "WHERE nome_localidade =  '" + teste + "')";
     // String sql = "select distinct * from projeto,gerente,localidade where nome_localidade = '" + teste + "'";
 
               try {
            ct = conexao.createStatement();
            rs = ct.executeQuery(sql); 
             while (rs.next())
      {
   int id = rs.getInt("id_localidade");
       String nomeLocalidade= rs.getString("nome_localidade");
        
    System.out.println(rs.getString("nome_gerente")+"    -    "+rs.getString("nome_projeto")+" - "+rs.getString("nome_localidade"));
           
             }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }    
         
         
         
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
         
         
         
      public void localizarAll(String teste, Gerente gerente){
       
       Statement ct = null;
      String sql = "select nome_localidade from localidade where nome_gerente = '" + teste + "'";
      
      
      
      //SELECT `nome_gerente`, `nome_localidade` FROM `gerente`, `gerente_projeto_localidade`, `localidade` 
      //WHERE `localidade`.`id_localidade` 
      //IN (SELECT `localidade`.`id_localidade` FROM `localidade`)
      
      
      
      //SELECT DISTINCT `nome_gerente`, `nome_localidade` FROM `gerente`, `gerente_projeto_localidade`, `localidade` WHERE `localidade`.`id_localidade` IN (SELECT `localidade`.`id_localidade` FROM `localidade` WHERE `nome_localidade` = "Salvador")














//String sql = "Select * from gerente";
        try {
            ct = conexao.createStatement();
            rs = ct.executeQuery(sql); 
             while (rs.next())
      {
    int id = rs.getInt("id_gerente");
        String nomeGerente= rs.getString("nome_gerente");
       // System.out.format("%s,%s",id, nomeGerente);
          System.out.println(rs.getInt("id_gerente")+","+rs.getString("nome_gerente"));
         // System.out.println(rs.getString("nome_gerente"));
             }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }  
          
}
      
