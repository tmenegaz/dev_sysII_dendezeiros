/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author alunosenai
 */
@Entity
@Table(name = "gerente")
@NamedQueries({
    @NamedQuery(name = "Gerente.findAll", query = "SELECT g FROM Gerente g")})
public class Gerente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_gerente")
    private Integer idGerente;
    @Size(max = 20)
    @Column(name = "nome_gerente")
    private String nomeGerente;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "gerente")
    private List<GerenteProjetoLocalidade> gerenteProjetoLocalidadeList;

    public Gerente() {
    }

    public Gerente(Integer idGerente) {
        this.idGerente = idGerente;
    }

    public Integer getIdGerente() {
        return idGerente;
    }

    public void setIdGerente(Integer idGerente) {
        this.idGerente = idGerente;
    }

    public String getNomeGerente() {
        return nomeGerente;
    }

    public void setNomeGerente(String nomeGerente) {
        this.nomeGerente = nomeGerente;
    }

    public List<GerenteProjetoLocalidade> getGerenteProjetoLocalidadeList() {
        return gerenteProjetoLocalidadeList;
    }

    public void setGerenteProjetoLocalidadeList(List<GerenteProjetoLocalidade> gerenteProjetoLocalidadeList) {
        this.gerenteProjetoLocalidadeList = gerenteProjetoLocalidadeList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idGerente != null ? idGerente.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Gerente)) {
            return false;
        }
        Gerente other = (Gerente) object;
        if ((this.idGerente == null && other.idGerente != null) || (this.idGerente != null && !this.idGerente.equals(other.idGerente))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Gerente[ idGerente=" + idGerente + " ]";
    }
    
}
