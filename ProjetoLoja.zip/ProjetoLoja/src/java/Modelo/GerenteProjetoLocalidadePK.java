/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author alunosenai
 */
@Embeddable
public class GerenteProjetoLocalidadePK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "id_gerente")
    private int idGerente;
    @Basic(optional = false)
    @Column(name = "id_projeto")
    private int idProjeto;
    @Basic(optional = false)
    @Column(name = "id_localidade")
    private int idLocalidade;

    public GerenteProjetoLocalidadePK() {
    }

    public GerenteProjetoLocalidadePK(int idGerente, int idProjeto) {
        this.idGerente = idGerente;
        this.idProjeto = idProjeto;
    }

    public int getIdGerente() {
        return idGerente;
    }

    public void setIdGerente(int idGerente) {
        this.idGerente = idGerente;
    }

    public int getIdProjeto() {
        return idProjeto;
    }

    public void setIdProjeto(int idProjeto) {
        this.idProjeto = idProjeto;
    }
    
      public int getIdLocalidade() {
        return idLocalidade;
    }

    public void setIdLocalidade(int idLocalidade) {
        this.idLocalidade = idLocalidade;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.idGerente;
        hash = 41 * hash + this.idProjeto;
        hash = 41 * hash + this.idLocalidade;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GerenteProjetoLocalidadePK other = (GerenteProjetoLocalidadePK) obj;
        if (this.idGerente != other.idGerente) {
            return false;
        }
        if (this.idProjeto != other.idProjeto) {
            return false;
        }
        if (this.idLocalidade != other.idLocalidade) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "GerenteProjetoLocalidadePK{" + "idGerente=" + idGerente + ", idProjeto=" + idProjeto + ", idLocalidade=" + idLocalidade + '}';
    }

   
}
