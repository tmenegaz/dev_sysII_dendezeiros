/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author alunosenai
 */
@Entity
@Table(name = "gerente_projeto_localidade")
@NamedQueries({
    @NamedQuery(name = "GerenteProjetoLocalidade.findAll", query = "SELECT g FROM GerenteProjetoLocalidade g")})
public class GerenteProjetoLocalidade implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected GerenteProjetoLocalidadePK gerenteProjetoLocalidadePK;
    @JoinColumn(name = "id_gerente", referencedColumnName = "id_gerente", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Gerente gerente;
    @JoinColumn(name = "id_projeto", referencedColumnName = "id_projeto", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Projeto projeto;
    @JoinColumn(name = "id_localidade", referencedColumnName = "id_localidade")
    @ManyToOne(optional = false)
    private Localidade idLocalidade;

    public GerenteProjetoLocalidade() {
    }

    public GerenteProjetoLocalidade(GerenteProjetoLocalidadePK gerenteProjetoLocalidadePK) {
        this.gerenteProjetoLocalidadePK = gerenteProjetoLocalidadePK;
    }

    public GerenteProjetoLocalidade(int idGerente, int idProjeto) {
        this.gerenteProjetoLocalidadePK = new GerenteProjetoLocalidadePK(idGerente, idProjeto);
    }

    public GerenteProjetoLocalidadePK getGerenteProjetoLocalidadePK() {
        return gerenteProjetoLocalidadePK;
    }

    public void setGerenteProjetoLocalidadePK(GerenteProjetoLocalidadePK gerenteProjetoLocalidadePK) {
        this.gerenteProjetoLocalidadePK = gerenteProjetoLocalidadePK;
    }

    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        this.gerente = gerente;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public Localidade getIdLocalidade() {
        return idLocalidade;
    }

    public void setIdLocalidade(Localidade idLocalidade) {
        this.idLocalidade = idLocalidade;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (gerenteProjetoLocalidadePK != null ? gerenteProjetoLocalidadePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GerenteProjetoLocalidade)) {
            return false;
        }
        GerenteProjetoLocalidade other = (GerenteProjetoLocalidade) object;
        if ((this.gerenteProjetoLocalidadePK == null && other.gerenteProjetoLocalidadePK != null) || (this.gerenteProjetoLocalidadePK != null && !this.gerenteProjetoLocalidadePK.equals(other.gerenteProjetoLocalidadePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.GerenteProjetoLocalidade[ gerenteProjetoLocalidadePK=" + gerenteProjetoLocalidadePK + " ]";
    }
    
}
