import React, { Component } from "react";
import { Redirect } from 'react-router-dom';
//import axios from 'axios';



//var cores = ["azul","verde","vermelho","amarelo"];
//var frutas = ["maçã","jaca","morango","cajá"];

class Formulario extends Component{

	 constructor(props) {
    super(props);
    this.state = {
    	palavra: '' ,
      redireciona: false,
      busca: ''
    };

    this.operacaoAnalise = this.operacaoAnalise.bind(this);
    this.enviar = this.enviar.bind(this);
  }

  operacaoAnalise(event) {
    this.setState({
      palavra: event.target.value
    });
  }
  
  enviar(event) {

    var checar = this.state.palavra
    if (checar) {
      this.setState({ redireciona: true, busca: checar });
    }

    event.preventDefault(); 
  }  

	render(){

		return(
				<div className="col-sm-8">
					<form className="form-inline" onSubmit={this.enviar}>
					  <div className="form-group">
					    <label htmlFor="email">Digite sua Busca: </label>
					    <input type="text" className="form-control" value={this.state.palavra} onChange={this.operacaoAnalise} placeholder="Escreva Algo"/>
					  </div>
					  <div className="form-group">
					    <button type="submit" className="btn btn-default">Buscar</button>
					  </div>
					  
					</form>
          {this.state.redireciona === true &&
            <Redirect to={"/buscar/" + encodeURI(this.state.busca)}/>
          }

				</div>
			);
	}
}
export default Formulario