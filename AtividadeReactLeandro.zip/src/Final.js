import React, { Component } from 'react';


var cores = ["azul","verde","vermelho","amarelo"];
var frutas = ["maçã","jaca","morango","cajá"];


class Final extends Component{
	constructor(props) {
    super(props);
    this.state = {
      mensagem: '',
    }
}
	/*exibir(props) {
		var busca = this.props.match.params.username;
		if (busca.toLowerCase() === "cores") {
			const Grupo = "cores";
			const mensagem = "Componentes do grupo: "+cores;
			return (
				<div>
					<h1>{this.props.Grupo}</h1>
					<h3>{this.props.mensagem}</h3>
				</div>	
				);
		}
	}*/

  render(){
  	   var param = this.props.match.params.grupo
       console.log(this.props);
       if (param.toLowerCase() === "cores") {
       		return(
			       	<div className="col-sm-12 text-center">
			          <h1>Grupo: Cores</h1>
			          <h3>Componentes do grupo:</h3>
			          <ul className="lista">
						<li>Azul</li>
						<li>Verde</li>
						<li>Vermelho</li>
						<li>Amarelo</li>
					  </ul>
			        </div>
       			);
       } else if(param.toLowerCase() === "frutas"){
       		return (
			       	<div className="col-sm-12 text-center">
			          <h1>Grupo: Frutas</h1>
			          <h3>Componentes do grupo:</h3>
			          <ul className="lista">
						<li>Maçã</li>
						<li>Jaca</li>
						<li>Morango</li>
						<li>Cajá</li>
					  </ul>
			        </div>
       			);
       } else {
       	var indiceCor = cores.indexOf(param.toLowerCase());
        var indiceFrut = frutas.indexOf(param.toLowerCase());

        if (indiceCor >= 0 && indiceCor <= 3) {
        	return (
			       	<div className="col-sm-12 text-center">
			          <h1>Grupo: Cores</h1>
			          <h3>Componentes do grupo:</h3>
			          <ul className="lista">
						<li>Azul</li>
						<li>Verde</li>
						<li>Vermelho</li>
						<li>Amarelo</li>
					  </ul>
			        </div>
       			);
        } else if (indiceFrut >= 0 && indiceFrut <= 3) {
        	return (
			       	<div className="col-sm-12 text-center">
			          <h1>Grupo: Futas</h1>
			          <h3>Componentes do grupo: {this.frutas}</h3>
			          <ul className="lista">
						<li>Maçã</li>
						<li>Jaca</li>
						<li>Morango</li>
						<li>Cajá</li>
					  </ul>
			        </div>
       			);
        } else {
        	return (
			       	<div className="col-sm-12 text-center">
			          <h1>{param} Não pertence a nenhum grupo</h1>
			        </div>
       			);
        }
       }
  }
};

export default Final;