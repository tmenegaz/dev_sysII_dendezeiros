import React from "react";
import { BrowserRouter, Route, Link } from 'react-router-dom';
import Formulario from './Formulario';
import Final from'./Final';





class Main extends React.Component {
  render() {
    return (
		<BrowserRouter>
			<div className="container-fluid">
				<nav className="navbar navbar-inverse">
					<div className="container-fluid">
						<div className="navbar-header">
							<p className="navbar-brand"><Link to="/">Atividade - React Form</Link></p>

						</div>
						<div className="collapse navbar-collapse" id="myNavbar">
							<ul className="nav navbar-nav">
							<li><Link to="/">Início</Link></li>
							{/*<li><Link to="/UserPage/Teste55">UserPage</Link></li>*/}
							</ul>
						</div>
					</div>
				</nav>
				<div className="row" id="listas">
					<div className="col-sm-6 jumbotron">
					   <h1>Cores</h1>
							<ul className="lista">
								<li>azul</li>
								<li>verde</li>
								<li>vermelho</li>
								<li>amarelo</li>
							</ul>
						
					</div>
				    <div className="col-sm-6 jumbotron">
				      <h1>Frutas</h1>
						  <ul className="lista">
							<li>Maçã</li>
							<li>Jaca</li>
							<li>Morango</li>
							<li>Cajá</li>
						  </ul>
				    </div>
				</div>

				<div className="row">
						<div className="col-sm-4"></div>
						<Route exact path="/" component={Formulario}/>
						{/* Parameters are defined by placing a colon before a word. */}
						{/* In this case, `username` is a parameter. */}
						{/* Parameters will be passed to the component. */}
						<Route path="/buscar/:grupo" component={Final}/>
				</div>

				<footer className="container-fluid text-center">
  					<p>Rodapé</p>
				</footer>
				
			</div>
		</BrowserRouter>
    );
  }
}
export default Main;