import React, { Component } from 'react';

class Resultado