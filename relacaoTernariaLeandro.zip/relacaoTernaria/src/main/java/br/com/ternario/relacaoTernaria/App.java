package br.com.ternario.relacaoTernaria;

import org.hibernate.Session;
import Config.HibernateUtil;
import DAO.*;
import Model.*;


public class App 
{
    public static void main( String[] args )
    {
    	Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

      /*  // Testar conexão com o banco
        String sql = "select version()";

        String result = (String) session.createNativeQuery(sql).getSingleResult();
        System.out.println(result);

        session.getTransaction().commit();
        session.close();

        
        HibernateUtil.shutdown();*/
        
       Cliente c = new Cliente();
        ClienteDAO cd = new ClienteDAO();
        
        c.setNomeCliente("Aryane");
        c.setCpfCliente("12345678910");
        c.setTelefone("11111111");
        
        cd.Salvar(c);

        
        Produto p = new Produto();
        ProdutoDAO pd = new ProdutoDAO();
        
        p.setNomeProduto("Café solúvel");
        p.setPreco(2.5);
        p.setQtdProduto(5);
        
        pd.Salvar(p);

        
        Vendedor v = new Vendedor();
        VendedorDAO vd = new VendedorDAO();
        
        v.setNomeVendedor("");
        v.setCpfVendedor("12345678911");
        
        vd.Salvar(v);

        VendasDAO vnd = new VendasDAO();
        
        vnd.Salvar(c, p, v);
        vnd.listarAll();

    }
}
