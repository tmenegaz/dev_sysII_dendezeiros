package DAO;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Config.HibernateUtil;
import Model.Produto;

public class ProdutoDAO {
	

	 private Session sessao = null;
	    private Transaction tx = null;
	    public ProdutoDAO() {
	    }
	    
	    
	    public void Salvar(Produto p){
	        try{
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        sessao.save(p);
	        tx.commit();
	            System.out.println("Produto Cadastrado com sucesso");
	        } catch(HibernateException e){
	            
	        } finally{
	            sessao.close();
	        }
	    }
	    
	    public void listarAll(){
	    
	        List<Produto> list = null;
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        
	        list = sessao.createQuery("from Produto").list();
	        tx.commit();
	        
	        for(Produto p : list){
	            System.out.println("Produto: " +p.getNomeProduto());
	        }
	        sessao.close();
	        
	    }

}
