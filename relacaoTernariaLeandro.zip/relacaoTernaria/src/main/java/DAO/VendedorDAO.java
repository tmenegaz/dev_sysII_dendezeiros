package DAO;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Config.HibernateUtil;
import Model.*;

public class VendedorDAO {
	
	 private Session sessao = null;
	    private Transaction tx = null;
	   
	    
	    public void Salvar(Vendedor v){
	        try{
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        sessao.save(v);
	        tx.commit();
	            System.out.println("Vendedor Cadastrado com sucesso");
	        } catch(HibernateException e){
	            
	        } finally{
	            sessao.close();
	        }
	    }
	    
	    public void listarAll(){
	    
	        List<Vendedor> list = null;
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        
	        list = sessao.createQuery("from Vendedor").list();
	        tx.commit();
	        
	        for(Vendedor v : list){
	            System.out.println("Vendedor: " +v.getNomeVendedor());
	        }
	        sessao.close();
	        
	    }
}
