package DAO;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Config.HibernateUtil;
import Model.*;

public class VendasDAO {
	
	private Session sessao = null;
    private Transaction tx = null;
    
    
    public void Salvar(Cliente c, Produto p, Vendedor v){
        try{
        	Vendas vnd = new Vendas();
        	vnd.setCliente(c);
        	vnd.setProduto(p);
        	vnd.setVendedor(v);
        sessao = HibernateUtil.getSessionFactory().openSession();
        tx = sessao.beginTransaction();
        sessao.save(vnd);
        tx.commit();
            System.out.println("Venda Registrada com sucesso");
        } catch(HibernateException e){
            
        } finally{
            sessao.close();
        }
    }
    
    public void listarAll(){
    
        List<Vendas> list = null;
        sessao = HibernateUtil.getSessionFactory().openSession();
        tx = sessao.beginTransaction();
        
        list = sessao.createQuery("from Vendas").list();
        tx.commit();
        
        for(Vendas vnd : list){
            System.out.println("Cliente: " +vnd.getCliente().getNomeCliente() +"  Vendedor: " +vnd.getVendedor().getNomeVendedor()+"  Produto: " +vnd.getProduto().getNomeProduto());
        }
        sessao.close();
    }
}
