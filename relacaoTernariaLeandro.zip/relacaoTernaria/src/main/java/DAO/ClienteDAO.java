package DAO;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Config.HibernateUtil;
import Model.Cliente;


public class ClienteDAO {
	
	 private Session sessao = null;
	    private Transaction tx = null;
	    public ClienteDAO() {
	    }
	    
	    
	    public void Salvar(Cliente c){
	        try{
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        sessao.save(c);
	        tx.commit();
	            System.out.println("Cliente Cadastrado com sucesso");
	        } catch(HibernateException e){
	            
	        } finally{
	            sessao.close();
	        }
	    }
	    
	    public void listarAll(){
	    
	        List<Cliente> list = null;
	        sessao = HibernateUtil.getSessionFactory().openSession();
	        tx = sessao.beginTransaction();
	        
	        list = sessao.createQuery("from Cliente").list();
	        tx.commit();
	        
	        for(Cliente c : list){
	            System.out.println("Cliente: " +c.getNomeCliente());
	        }
	        sessao.close();
	        
	    }

}
