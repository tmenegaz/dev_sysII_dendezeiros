/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.views;

import org.model.bean.Cliente;
import org.model.bean.Produto;
import org.model.bean.Venda;
import org.model.bean.Vendedor;
import org.model.dao.ClienteDao;
import org.model.dao.ProdutoDao;
import org.model.dao.VendaDao;
import org.model.dao.VendedorDao;

/**
 *
 * @author alunosenai
 */
public class TesteVenda {
    public static void main(String[] args) {
        Cliente cliente = new Cliente();
        ClienteDao dc = new ClienteDao();
        cliente.setNomeC("TesteCliente");
        dc.Salvar(cliente);
        
        Produto produto = new Produto();
        ProdutoDao dp = new ProdutoDao();
        produto.setNomeP("Teclado");
        dp.Salvar(produto);
        
        Vendedor vendedor = new Vendedor();
        vendedor.setNomeV("TesteVendedor");
        VendedorDao dv = new VendedorDao();
        dv.Salvar(vendedor);
        
        Venda venda = new Venda();
        venda.setClientes(cliente);
        venda.setProdutos(produto);
        venda.setVendedores(vendedor);
        VendaDao vvd = new VendaDao();
        vvd.Salvar(vendedor, produto, cliente);
        
    }
}
