/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.model.bean;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author Marcos
 */
@Entity
public class Venda implements Serializable {

 //   @Id
 //   private int id_venda;
    @Id
    @ManyToOne
    private Produto produtos;
    
    @Id
    @ManyToOne
    private Cliente clientes;
    
    @Id
    @ManyToOne
    private Vendedor vendedores;

//    public int getId_venda() {
//        return id_venda;
//    }
//
//    public void setId_venda(int id_venda) {
//        this.id_venda = id_venda;
//    }

    public Produto getProdutos() {
        return produtos;
    }

    public void setProdutos(Produto produtos) {
        this.produtos = produtos;
    }

    public Cliente getClientes() {
        return clientes;
    }

    public void setClientes(Cliente clientes) {
        this.clientes = clientes;
    }

    public Vendedor getVendedores() {
        return vendedores;
    }

    public void setVendedores(Vendedor vendedores) {
        this.vendedores = vendedores;
    }
    
    

}
