(function(){

    var acertos = 0;
	var images = [];

	var flippedCards = [];

	var fim = document.querySelector("#fim");

	var imgAcertouSign = document.querySelector("#imgAcertouSign");
	
	for(var i = 0; i<6; i++){
		var img = {
			src: "img/" + i + ".png",
			id: i%3
		};

		images.push(img);
	}

 startGame();

 function startGame(){

 	acertos = 0;

 	flippedCards = [];

 	images = randomSort(images);

 	var frontFaces = document.getElementsByClassName("front");
 	var backFaces = document.getElementsByClassName("back");

 	for(var i=0; i<6; i++){
     frontFaces[i].classList.remove("flipped","acertou");
      backFaces[i].classList.remove("flipped","acertou");


 	var card = document.querySelector("#card" + i);
 	card.style.left = i % 3 === 0 ? 5 + "px" : i % 3 * 235 + 5 + "px";
    card.style.top =  i < 3 ? 5 + "px" : 240 + "px";

    card.addEventListener("click",flipCard, false);

    frontFaces[i].style.background = "url('"+ images[i].src + "')";
    frontFaces[i].setAttribute("id", images[i].id);
  
 	}

 	fim.style.zIndex = -2;
    fim.removeEventListener("click",startGame,false);
 }

 function randomSort(oldArray){

    var newArray = [];

    while(newArray.length !== oldArray.length){
    	var i= Math.floor(Math.random()* oldArray.length);

        if(newArray.indexOf(oldArray[i]) < 0){

        	newArray.push(oldArray[i]);
        }
    }
    
    return newArray;
 }

 function flipCard(){

  if(flippedCards.length < 2){

  var faces = this.getElementsByClassName("face");

  if(faces[0].classList.length > 2){
  	return;
  }

  faces [0].classList.toggle("flipped");
  faces [1].classList.toggle("flipped");

  flippedCards.push(this);

  if(flippedCards.length === 2){

  if(flippedCards[0].childNodes[3].id === flippedCards[1].childNodes[3].id){
  	  
  	  flippedCards[0].childNodes[1].classList.toggle("acertou");
      flippedCards[0].childNodes[3].classList.toggle("acertou");      
      flippedCards[1].childNodes[1].classList.toggle("acertou");
      flippedCards[1].childNodes[3].classList.toggle("acertou");

      acertouCardSign();

      acertos++;

      flippedCards = [];

      if(acertos === 3){
     	fim();

        }

      }

    }

  } else {
  	
      flippedCards[0].childNodes[1].classList.toggle("flipped");
      flippedCards[0].childNodes[3].classList.toggle("flipped");      
      flippedCards[1].childNodes[1].classList.toggle("flipped");
      flippedCards[1].childNodes[3].classList.toggle("flipped");

      flippedCards = [];
  }
  
 }
 
 function final(){ 
 fim.style.zIndex = -2;
 fim.addEventListener("click",startGame,false);

 }

function acertouCardSign(){
  imgAcertouSign.style.zIndex = 1;
  imgAcertouSign.style.top= 150 + "px";
  imgAcertouSign.style.opacity = 0;
  setTimeout(function(){
  imgAcertouSign.style.zIndex = -1;
  imgAcertouSign.style.top= 250 + "px";
  imgAcertouSign.style.opacity = 1;

  },1500);
 }
}());