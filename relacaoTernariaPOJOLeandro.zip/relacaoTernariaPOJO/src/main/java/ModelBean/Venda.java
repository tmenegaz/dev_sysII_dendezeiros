package ModelBean;

public class Venda {
	
	private Produto produto;
	private Cliente cliente;
	private Vendedor vendedor;
	
	private int idProduto;
	private int idCliente;
	private int idVendedor;
	
	
	public int getIdProduto() {
		return idProduto;
	}
	 
	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public int getIdVendedor() {
		return idVendedor;
	}
	public void setIdVendedor(int idVendedor) {
		this.idVendedor = idVendedor;
	}
	
	
}
