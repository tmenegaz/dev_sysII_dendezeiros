package ModelBean;

import java.util.HashSet;
import java.util.Set;

public class Produto {
	private int IdProduto;
	private String NomeProduto;
	private int Quantidade;
	private double Preco; 
	private String UnidadeMedida;
	private  Set<Venda> vendas = new HashSet<Venda>(0);

	

	
	public String getNomeProduto() {
		return NomeProduto;
	}
	public void setNomeProduto(String nomeProduto) {
		NomeProduto = nomeProduto;
	}
	public int getIdProduto() {
		return IdProduto;
	}
	public void setIdProduto(int idProduto) {
		IdProduto = idProduto;
	}
	
	public int getQuantidade() {
		return Quantidade;
	}
	public void setQuantidade(int quantidade) {
		Quantidade = quantidade;
	}
	public double getPreco() {
		return Preco;
	}
	public void setPreco(double preco) {
		Preco = preco;
	}
	public String getUnidadeMedida() {
		return UnidadeMedida;
	}
	public void setUnidadeMedida(String unidadeMedida) {
		UnidadeMedida = unidadeMedida;
	}

}
