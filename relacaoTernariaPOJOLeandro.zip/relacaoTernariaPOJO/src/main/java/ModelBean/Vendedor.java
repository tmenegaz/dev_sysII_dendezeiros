package ModelBean;

import java.util.HashSet;
import java.util.Set;

public class Vendedor {
	
	private int IdVendedor;
	private String NomeVendedor;
	private String CPF;

	
	public int getIdVendedor() {
		return IdVendedor;
	}
	public void setIdVendedor(int idVendedor) {
		IdVendedor = idVendedor;
	}
	public String getNomeVendedor() {
		return NomeVendedor;
	}
	public void setNomeVendedor(String nomeVendedor) {
		NomeVendedor = nomeVendedor;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	
}
