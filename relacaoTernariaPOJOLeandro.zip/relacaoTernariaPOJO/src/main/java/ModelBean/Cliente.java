package ModelBean;

import java.util.HashSet;
import java.util.Set;

public class Cliente {
	private int IdCliente;
	private String Nome;
	private String CPF;
	private String Telefone;
	private  Set<Venda> vendas = new HashSet<Venda>(0);
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getCPF() {
		return CPF;
	}

	public int getIdCliente() {
		return IdCliente;
	}
	public void setIdCliente(int idCliente) {
		IdCliente = idCliente;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public String getTelefone() {
		return Telefone;
	}
	public void setTelefone(String telefone) {
		Telefone = telefone;
	}
}
