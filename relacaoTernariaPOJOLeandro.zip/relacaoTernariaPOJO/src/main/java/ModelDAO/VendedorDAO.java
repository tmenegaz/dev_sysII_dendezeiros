package ModelDAO;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import ModelBean.*;
import utilitarios.ConnectDAO;

public class VendedorDAO {
	
	private ConnectDAO db = new ConnectDAO();
	private Vendedor v = new Vendedor();
	
	public void addVendedor(Vendedor v) {
		db.conexao();
		
		try {
			PreparedStatement pst = db.conn.prepareStatement("insert INTO vendedor (nomeVendedor, cpfVendedor) VALUES (?,?)");
			pst.setString(1, v.getNomeVendedor());
			pst.setString(2, v.getCPF());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null,"Vendedor adicionado com sucesso");
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Erro: \n" +ex.getMessage());
		}
		
		db.desconectar();
		
	}


}
