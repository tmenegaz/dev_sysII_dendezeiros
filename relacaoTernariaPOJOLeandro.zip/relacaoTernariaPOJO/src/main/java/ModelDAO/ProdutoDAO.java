package ModelDAO;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import ModelBean.*;
import utilitarios.ConnectDAO;

public class ProdutoDAO {
	
	private ConnectDAO db = new ConnectDAO();

	
	public void addProduto(Produto p) {
		db.conexao();
		
		try {
			PreparedStatement pst = db.conn.prepareStatement("insert INTO produto (nomeProduto, qtdProduto, preco) VALUES (?,?,?)");
			pst.setString(1, p.getNomeProduto());
			pst.setInt(2, p.getQuantidade());
			pst.setDouble(3, p.getPreco());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null,"Produto adicionado com sucesso");
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Erro: \n" +ex.getMessage());
		}
		
		db.desconectar();
		
	}

	
	
}
