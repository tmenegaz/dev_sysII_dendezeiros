package ModelDAO;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import ModelBean.*;
import utilitarios.ConnectDAO;



public class VendaDAO {
	
	private ConnectDAO db = new ConnectDAO();
	
	
	public void venda(Produto p, Cliente c, Vendedor v) {
		   db.conexao();
		   Venda vn = new Venda();
		   
		 try {
			   db.executaSQL("select idProduto from produto where nomeProduto='"+p.getNomeProduto()+"' AND 	qtdProduto='"+p.getQuantidade()+"' And 	preco='"+p.getPreco()+"'");
			   db.executaSQL("select idVendedor from vendedor where nomeVendedor='"+v.getNomeVendedor()+" AND cpfVendedor='"+v.getCPF()+"'");
			   db.executaSQL("select idCliente from vendedor where nomeCliente='"+c.getNome()+" AND cpfCliente='"+c.getCPF()+"' AND telefone='"+c.getTelefone()+"'");
			   db.rs.first();
			   vn.setIdProduto(db.rs.getInt("idProduto"));
			   vn.setIdCliente(db.rs.getInt("idCliente"));
			   vn.setIdVendedor(db.rs.getInt("idVendedor"));
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Erro \n" + ex.getMessage());
		}
		      
		   try {
			   
			   PreparedStatement pst = db.conn.prepareStatement("insert INTO vendas (idCliente, idProduto, idVendedor) VALUES (?,?,?)");
			   pst.setInt(2, vn.getIdCliente());
			   pst.setInt(1, vn.getIdProduto());
		       pst.setInt(3, vn.getIdVendedor());
		       pst.executeUpdate();
		   } catch (Exception ex) {
			   
			   JOptionPane.showMessageDialog(null,"Erro \n" + ex.getMessage());
			   
		   }
		            db.desconectar();
		   }
	

}
