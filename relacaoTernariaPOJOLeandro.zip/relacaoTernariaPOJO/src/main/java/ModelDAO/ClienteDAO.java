package ModelDAO;

import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import ModelBean.Cliente;
import utilitarios.ConnectDAO;

public class ClienteDAO {
	private ConnectDAO db = new ConnectDAO();
	private Cliente c = new Cliente();
	
	public void addCliente(Cliente c) {
		db.conexao();
		
		try {
			PreparedStatement pst = db.conn.prepareStatement("insert INTO cliente (nomeCliente, cpfCliente, telefone) VALUES (?,?,?)");
			pst.setString(1, c.getNome());
			pst.setString(2, c.getCPF());
			pst.setString(3, c.getTelefone());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null,"Cliente adicionado com sucesso");
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null,"Erro: \n" +ex.getMessage());
		}
		
		db.desconectar();
		
	}

}

