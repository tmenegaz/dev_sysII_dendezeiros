package utilitarios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConnectDAO {
	
	public Statement stm;
    public ResultSet rs;
    private final String driver = "com.mysql.jdbc.Driver";
    private final String caminho = "jdbc:mysql://localhost/relacaoternaria";//Verificar o nome do banco
    private final String usuario = "root";
    private final String senha = "";
    public Connection conn;
    
    
    public void conexao(){
  	
   try {
	   System.setProperty("jdbc.Drivers", driver);
	   conn = DriverManager.getConnection(caminho, usuario, senha);
	   //JOptionPane.showMessageDialog(null,"Conectado com sucesso!");
	   
   } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro:\n" + ex.getMessage());
            
        }
    }
    
    public void executaSQL(String sql){
        
        try {
            stm = conn.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"Erro no executa SQL" + ex.getMessage());
           
        }
        
        
    }
     
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
     
    }   
}
