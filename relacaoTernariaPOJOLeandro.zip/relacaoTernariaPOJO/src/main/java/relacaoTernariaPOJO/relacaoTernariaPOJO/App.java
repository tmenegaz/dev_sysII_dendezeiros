package relacaoTernariaPOJO.relacaoTernariaPOJO;
import ModelBean.*;
import ModelDAO.*;


public class App 
{
    public static void main( String[] args )
    {
    	
    	Cliente c = new Cliente();
    	c.setNome("Jim");
    	c.setCPF("22222222222");
    	c.setTelefone("071999999999");
    	
    	ClienteDAO cl = new ClienteDAO();
    	
    	cl.addCliente(c);
    	
    	Vendedor v = new Vendedor();
    	v.setNomeVendedor("Joãozinho dos santos");
    	v.setCPF("99999999999");
    	
    	VendedorDAO vnd = new VendedorDAO();
    	vnd.addVendedor(v);
    	
    	Produto p = new Produto();
    	p.setNomeProduto("Sabão líquido OMO");
    	p.setQuantidade(100);
    	p.setPreco(17.95);
    	
    	ProdutoDAO pd = new ProdutoDAO();
    	pd.addProduto(p);		
    			
    	
    	VendaDAO vn = new VendaDAO();
    	
    	vn.venda(p, c, v);
    	
    	
    }
}
;