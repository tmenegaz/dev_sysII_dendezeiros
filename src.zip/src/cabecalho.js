import React from "react";

export default class Cabeca extends React.Component {
	render(){
		return (
			<header>
			<h1>Municipios ou Estados?</h1>
				<div id="list">
					<ul id="glist">
						<li id="g1">Municipios
							<ul>
								<li>Salvador</li>
								<li>Vitória da Conquista</li>
								<li>
								</li>
								<li>Porto Seguro</li>
							</ul>
						</li>
						<li id="g2">Estados
							<ul>
								<li>Bahia</li>
								<li>Rio de Janeiro</li>
								<li>São Paulo</li>
								<li>Recife</li>
							</ul>
						</li>
					</ul>
				</div>
			</header>
			);
	}
}