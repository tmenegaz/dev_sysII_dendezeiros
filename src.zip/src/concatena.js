import React from 'react';
import Cabeca from './cabecalho';
import Rodape from './foot';


var municipios = ["salvador","Salvador","vitoria da conquista","Vitoria da Conquista","ilheus","Ilheus","porto seguro", "Porto Seguro"];
var estados = ["bahia","Bahia","rio de janeiro","Rio de Janeiro", "são paulo", "São Paulo", "sao paulo", "recife", "Recife"];


export default class Concatena extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
    	palavra: ''    
    };

    this.operacaoAnalise = this.operacaoAnalise.bind(this);
    this.enviar = this.enviar.bind(this);
  }

  operacaoAnalise(event) {
    this.setState({
      palavra: event.target.value
    });
  }
  
  enviar(event) {

     var item = this.state.palavra

     if(item.toLowerCase() === "municipios"){

        resultado = "O grupo " + item + " contém os seguintes elementos: " + municipios;
        document.getElementById('h').innerHTML = resultado;

     }else if(item.toLowerCase() === "estados"){

        resultado = "O grupo " + item + " contém os seguintes elementos: " + estados;
        document.getElementById('h').innerHTML = resultado;

     }else{

        var resultado = '';
        var indiceMun = municipios.indexOf(item.toLowerCase());
        var indiceEst = estados.indexOf(item.toLowerCase());

        if(indiceMun >= 0 && indiceMun <= 3){

          resultado = "" + municipios[indiceMun] + " é do grupo de Municipios.";
          document.getElementById('h').innerHTML = resultado;

        }else if(indiceEst >= 0 && indiceEst <= 3){

          resultado = "" + estados[indiceEst] + " é do grupo de Estados.";
          document.getElementById('h').innerHTML = resultado;

        }else{

          resultado = "" + item + " não pertence a nenhum dos grupos!";
          document.getElementById('h').innerHTML = resultado;
        }  

     }

      event.preventDefault(); 

  }  

  render() {
    return (
    	<div>
    	<Cabeca />
      <div id="conteudo">
        <form onSubmit={this.enviar}>
          <label>
            Item
          </label>
            <input type="text"
            value={this.state.palavra} onChange={this.operacaoAnalise}></input>
          <button type="submit">OK</button>
        </form>
      </div>
      <Rodape />
      </div>
    );
  }
}