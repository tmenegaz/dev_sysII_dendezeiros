import React from 'react';
import ReactDOM from 'react-dom';
import Concatena from './concatena';



ReactDOM.render(
	<Concatena />,
	document.getElementById('root')
);