import React from 'react';



export default class Rodape extends React.Component {

	render(){
		return (
			<footer>
				<h3>Resultado</h3>
				<h4 id="h"></h4>
			</footer>
			);
	}
}