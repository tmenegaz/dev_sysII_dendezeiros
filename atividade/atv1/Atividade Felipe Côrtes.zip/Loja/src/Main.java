
import Controle.DAO;
import Modelo.Gerente;
import Modelo.GerenteProjetoLocalidade;
import Modelo.Localidade;
import Modelo.Projeto;

public class Main{
public static void main(String[] args) {
		
                DAO dao = new DAO();
		//Criando um primeiro contato             
                
               Gerente gerente = new Gerente();
                gerente.setNomeGerente("Gerente 1");
		dao.salvar(gerente);
                
                Projeto projeto = new Projeto();
                projeto.setNomeProjeto("Projeto 2");
                dao.salvar(projeto);
                
                Localidade localidade = new Localidade();
                localidade.setNome("Localidade 1");
                dao.salvar(localidade);
                
                GerenteProjetoLocalidade gpl = new GerenteProjetoLocalidade();
                gpl.setIdGerente(gerente.getIdGerente());
                gpl.setIdProjeto(projeto.getIdProjeto());
                gpl.setIdLocalidade(localidade.getIdLocalidade());
                dao.salvar(gpl);
                
		// Criando um segundo contato
		                                
         	}
}