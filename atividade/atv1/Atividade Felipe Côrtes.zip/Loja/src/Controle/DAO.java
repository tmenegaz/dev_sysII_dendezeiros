package Controle;

import Modelo.Gerente;
import Modelo.GerenteProjetoLocalidade;
import Modelo.Localidade;
import Modelo.Projeto;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAO {

 
    Connection conexao = this.geraConexao();
	
    
    
    
    public void salvar(Gerente gerente) {
		PreparedStatement insereSt = null;
		String sql = "insert into gerente (nome_gerente) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1,gerente.getNomeGerente());
			insereSt.executeUpdate();
                        pesquisar(gerente);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Gerente: "
					+ e.getMessage());
		} 
    
    }
		
    
       public void salvar(Projeto projeto) {
		PreparedStatement insereSt = null;
		String sql = "insert into projeto (nome_projeto) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1,projeto.getNomeProjeto());
                                insereSt.executeUpdate();
                                pesquisar(projeto);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Projeto: "
					+ e.getMessage());
		} 
	}
    
    public void salvar(Localidade localidade) {
		PreparedStatement insereSt = null;
		String sql = "insert into localidade (nome_localidade) values (?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setString(1, localidade.getNome());
                                insereSt.executeUpdate();
                                pesquisar(localidade);
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Localidade: "
					+ e.getMessage());
		} 
    }
    
    
   public void pesquisar(Gerente gerente){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from gerente where nome_gerente =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,gerente.getNomeGerente());
            ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                gerente.setIdGerente(rs.getInt("id_gerente"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
   }
      public void pesquisar(Projeto projeto){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from projeto where nome_projeto =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,projeto.getNomeProjeto());
            ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                projeto.setIdProjeto(rs.getInt("id_projeto"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
                
         public void pesquisar(Localidade localidade){
       
       PreparedStatement insereSt = null; 
       String sql = "select * from localidade where nome_localidade =?";
        try {
            insereSt = conexao.prepareStatement(sql);
            insereSt.setString(1,localidade.getNome());
                    ResultSet rs = insereSt.executeQuery();
            
            if (rs.next()){
                
                localidade.setIdLocalidade(rs.getInt("id_localidade"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         }
         
         
          public void salvar(GerenteProjetoLocalidade gpl) {
		PreparedStatement insereSt = null;
		String sql = "insert into gerente_projeto_localidade (id_gerente,id_projeto,id_localidade) values (?,?,?)";
		try {
			insereSt = conexao.prepareStatement(sql);
                        insereSt.setInt(1,gpl.getIdGerente());
                        insereSt.setInt(2,gpl.getIdProjeto());
                        insereSt.setInt(3,gpl.getIdLocalidade());
                        insereSt.executeUpdate();
                               
		} catch (SQLException e) {
			System.out.println("Erro ao incluir contato. Mensagem Localidade: "
					+ e.getMessage());
		} 
    }

     
    

          private Connection geraConexao() {
		Connection conexao = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/loja";
			String usuario = "root";
			String senha = "";
			conexao = DriverManager.getConnection(url, usuario, senha);
		} catch (ClassNotFoundException e) {
			System.out
					.println("Classe não encontrada. Erro: " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Ocorreu um erro de SQL. Erro: "
					+ e.getMessage());
		}
		return conexao;
	}
          
}
      

