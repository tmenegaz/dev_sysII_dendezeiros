package PaginaPrincipal;


import Conexao.Conexao;
import Dao.ClienteDao;
import Dao.ProdutoDao;
import Dao.VendaDao;
import Dao.VendedorDao;
import bean.ClienteBean;
import bean.ProdutoBean; 
import bean.VendaBean;
import bean.VendedorBean;


public class Negocio {
    
 public static void main(String[] args){

  Conexao conexao;
  conexao = new Conexao();
 
  ClienteDao clientedao = new ClienteDao();
            
  ClienteBean cliente = new ClienteBean();
  cliente.setNomeCliente("Iracema");
  clientedao.cadastrarCliente(cliente);
  cliente.setNomeCliente("Iracema");
  clientedao.pesquisarCliente(cliente);
//  cliente.setNomeCliente("joana");
//  clientedao.excluirCliente(cliente);
//            
  
  ProdutoDao produtodao = new ProdutoDao();
            
  ProdutoBean produto = new ProdutoBean();
  produto.setNomeProd("Biscoito");
  produtodao.cadastrarProduto(produto);
  produto.setNomeProd("Biscoito");
  produtodao.pesquisarProduto(produto);
//  produto.setNomeProd("Maça");
//  produtodao.excluirProduto(produto);
  
            
  VendedorDao vendedordao = new VendedorDao();
            
  VendedorBean vendedor = new VendedorBean();
  vendedor.setNome("Isabela");
  vendedordao.cadastrarVendedor(vendedor);
  vendedor.setNome("Isabela");
  vendedordao.pesquisarVendedor(vendedor);
//  vendedor.setNome("Luciana");
//  vendedordao.excluirVendedor(vendedor);
  
            
  VendaDao vendaDao = new VendaDao();
            
  VendaBean venda = new VendaBean();
  venda.setIdCliente(cliente.getIdCliente());
  venda.setIdProd(produto.getIdProd());
  venda.setIdVendedor(vendedor.getIdVendedor());
  vendaDao.cadastrarVenda(venda);
 
  
 }   

}
