
package Menu;

import Dao.ClienteDao;
import bean.ClienteBean;
import java.util.Scanner;

/**
 *
 * @author Ian
 */
public class Cliente {
    
    public void Cliente(){
       
        Scanner entrada = new Scanner(System.in);
        ClienteBean cliente = new ClienteBean();
        ClienteDao dao = new ClienteDao();
        
        int a;
        String nome, cpf;
        
        System.out.println("Escolha a operação que deseja executar!");
        System.out.println("1 - Cadastrar Cliente");
        System.out.println("2 - Consultar Cliente");
        System.out.println("3 - Voltar para a tela inicial");
        System.out.print("Informe o número correspndente:  ");
        a=entrada.nextInt();
        
        switch(a){
            case 1:
                    System.out.print("Informe o nome do cliente:  ");
                    nome = entrada.nextLine();
                    //System.out.print("Informe o cpf:  ");
                    //cpf = entrada.nextLine();
                    cliente.setNomeCliente(nome);
                    dao.cadastrarCliente(cliente);
        }
    }
}
