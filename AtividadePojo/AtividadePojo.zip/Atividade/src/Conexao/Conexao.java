
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexao {
    
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String  CAMINHO = "jdbc:mysql://localhost/atividade";
    private static final String USUARIO = "root";
    private static final String SENHA = "iracema95";
    public Connection con;
    
    public static Connection getConnection(){
        
        try {
            
            Class.forName(DRIVER);
            return DriverManager.getConnection(CAMINHO, USUARIO, SENHA);   
        } catch (java.lang.ClassNotFoundException | SQLException ex) {
            throw new RuntimeException("Erro ao realizar conexão com o banco:  "+ex.getMessage());
           //JOptionPane.showMessageDialog(null,"Erro:  "+ ex.getMessage());
        }
    
      
  }
}
