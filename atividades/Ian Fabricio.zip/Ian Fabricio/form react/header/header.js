import React from "react";

export default class Header extends React.Component {
	render(){
		return (
			<div id="top">
			
				<div id="list">
				<h4>Escolha uma cidade que iremos informar o seu estado </h4>
					<ul>
						<li>Salvador</li>
						<li>Vitoria da Conquista</li>
						<li>Ilheus</li>
						<li>Porto Seguro</li>
						
					</ul>
				</div>
			</div>
			);
	}
}