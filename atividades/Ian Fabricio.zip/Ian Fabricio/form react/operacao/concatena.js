import React from 'react';

import Hello_wold from '../saudacao/hello_world';
import Rodape from '../resposta/saida';
import '../index.css';
import{Router, route} from 'react-router';

export default class Concatena extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {
    	nome: '',
    	snome: ''
    };

    this.operacaoNome = this.operacaoNome.bind(this);
    this.operacaoSnome = this.operacaoSnome.bind(this);
    this.enviar = this.enviar.bind(this);
  }

  operacaoNome(event) {
    this.setState({
      nome: event.target.value
    });
  }

  operacaoSnome(event){
  	this.setState({
  		snome: event.target.value
  	})
  }

  enviar(event) {

    switch(this.state.nome) {
    case "Salvador":
        alert("É do estado da Bahia");
        break;
     case "Vitoria da Conquista":
        alert("É do estado da Bahia");
        break;  
      case "Ilheus":
        alert("É do estado da Bahia");
        break; 
         case "Porto Seguro":
        alert("É do estado da Bahia");
        break;
        case "Belo Horizonte":
        alert("É do estado de Minas Gerais");
        break;
        case "Monte Carlos":
        alert("É do estado de Minas Gerais");
        break;
        case "Manaus":
        alert("É do estado do Amazonas");
        break;                                    
           
   
       
};
    
    
  }

  render() {
    return (
    	<div id="top">
      
    	<Hello_wold />
      <form onSubmit={this.enviar}>
        <label>
          Nome:
          <div>
          <input type="text" placeholder="Nome"
          value={this.state.nome}
          onChange={this.operacaoNome} />
          </div>
          
         
        </label>
        <button type="submit">apertar</button>
      </form>
      <Rodape />
      </div>
    );
  }
}
