import React from 'react';

export default class Rodape extends React.Component {

	render(){
		return <div className="footer"> <h2>Jorge Luis </h2> </div>
	}
}