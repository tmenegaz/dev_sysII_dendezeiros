import React from "react";

export default class Hello_world extends React.Component {
	render(){
		return (
			<div id="top">
			<h1>Atividade</h1>
				<div id="list">
					<h4>Escolha uma cidade que iremos informar o seu estado </h4>
					<ul>
						<li>Salvador</li>
						<li>Vitoria da Conquista</li>
						<li>Ilheus</li>
						<li>Porto Seguro</li>
                        <li>Belo Horizonte</li>
                        <li>Monte Carlos</li>
                        <li>Manaus</li>




						
					</ul>
				</div>
			</div>
			);
	}
}